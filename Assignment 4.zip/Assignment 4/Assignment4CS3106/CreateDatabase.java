
/**
 * A simple Database Design to allow for the insertion of both Full Time and Part Time Salary 
 * Records into the database. 
 * The database is MySQL and 
 * Sample data is avalaible in the folder dbpay
 * Each record has a unique,auto-incremented identifier to distinguish between records.
 * @author Piush,Guillaume,Damein,Jeffery 
 * @version 22042016
 */


public class CreateDatabase
{
    /*
use dbPay;
#create USER 'root' @ 'localhost3306' identified by '1234';
#grant all privileges on * . * to 'root' @ 'localhost3306';
create table tblFullTime // tblPartTime
(
id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
ppsn VARCHAR(20) NOT NULL,
name VARCHAR(100) NOT NULL,
salary double NOT NULL,
months double NOT NULL,
expenses double,
taxes double NOT NULL,
calculatedpay double NOT NULL
); 
*/
}
