package com.piushvaish;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertEquals;

public class StatsTest {

    @Test
    public void testMyInteger() {
        List<MyInteger> myList = new ArrayList<>();
        myList.add(new MyInteger(100));
        myList.add(new MyInteger(5));
        myList.add(new MyInteger(600));
        myList.add(new MyInteger(2));
        myList.add(new MyInteger(0));
        myList.add(new MyInteger(1));


        //minSoFar,maxSoFar,median in the StatisticsUtils
        Triple<MyInteger, MyInteger, MyInteger> stats = StatisticsUtils.getStats(myList);
        assertEquals(0, stats.getM1().value); 	// minimum
        assertEquals(5, stats.getM2().value); 	// median
        assertEquals(600, stats.getM3().value); // maximum
    }
    //minSoFar,maxSoFar,median in the StatisticsUtils
    @Test
    public void testEmptyList() {
        List<MyInteger> myList = new ArrayList<>();
        Triple<MyInteger, MyInteger, MyInteger> stats = StatisticsUtils.getStats(myList);
        assertEquals(null, stats.getM1()); // minimum
        assertEquals(null, stats.getM2()); // median
        assertEquals(null, stats.getM3()); // maximum
    }

    /**
     * The collection interface includes a method to bulk add elements to the collection from another collection.
     * The error is because of the need to control the type safety of the use of generic types.
     * The solution is by adding Comparable <? super E>> to the getstats method
     */
    @Test
    public void testMyInteger2() {
        List<MyInteger2> myList = new ArrayList<>();
        myList.add(new MyInteger2(100));
        myList.add(new MyInteger2(5));
        myList.add(new MyInteger2(600));
        myList.add(new MyInteger2(2));
        myList.add(new MyInteger2(0));
        myList.add(new MyInteger2(1));
        //minSoFar,maxSoFar,median in the StatisticsUtils
        Triple<MyInteger2, MyInteger2, MyInteger2> stats = StatisticsUtils.getStats(myList);
        assertEquals(0, stats.getM1().value); 	// minimum
        assertEquals(5, stats.getM2().value); 	// median
        assertEquals(600, stats.getM3().value); // maximum
    }
}