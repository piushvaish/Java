package com.piushvaish;

/**
 * Created by piush on 05/12/2016.
 */
public class Triple <S,T,U> {
    private S m1;
    private T m2;
    private U m3;

    public Triple(S v1, T v2, U v3) {
        this.m1 = v1;
        this.m2 = v2;
        this.m3 = v3;
    }

    public S getM1() {
        return m1;
    }

    public T getM2() {
        return m2;
    }

    public U getM3() {
        return m3;
    }

    @Override
    public String toString() {
        return "Triple{" +
                "m1=" + m1 +
                ", m2=" + m2 +
                ", m3=" + m3 +
                '}';
    }
}
