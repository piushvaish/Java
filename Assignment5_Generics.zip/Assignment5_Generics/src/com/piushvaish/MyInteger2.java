package com.piushvaish;

/**
 * Created by piush on 05/12/2016.
 */
public class MyInteger2 extends MyInteger {
    public MyInteger2(int val) {
        super(val);
    }
}
