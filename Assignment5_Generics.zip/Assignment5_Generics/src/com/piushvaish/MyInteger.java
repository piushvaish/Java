package com.piushvaish;

/**
 * Created by piush on 05/12/2016.
 */
public class MyInteger implements Comparable<MyInteger> {

    public int value;

    public MyInteger(int val){
        value = val;

    }

    @Override
    public int compareTo(MyInteger o) {
        return value - o.value;
    }
}
