package com.piushvaish;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * Created by piush on 05/12/2016.
 */
public class StatisticsUtils {
    //type-constrain the other collection such that its elements extend the same type as the receiving collection.

    public static <E extends Comparable<? super E>> Triple<E, E, E> getStats(Collection<E> c) {

        E minSoFar = null;
        E maxSoFar = null;

        for (E element : c) {
            if (minSoFar == null || element.compareTo(minSoFar) < 0) {
                minSoFar = element;
            }
            if (maxSoFar == null || element.compareTo(maxSoFar) >0) {
                maxSoFar = element;
            }
        }

        E median = null;
        if(c.size() > 0) {
            List<E> l = new ArrayList<>();

            l.addAll(c);
            Collections.sort(l);
            median = l.get((int) ((l.size() + 1) / 2));
        }
        return new Triple<E, E, E>(minSoFar,median,maxSoFar);

    }

}
